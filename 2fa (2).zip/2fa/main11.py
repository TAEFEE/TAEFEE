import os
import json
import bcrypt
import pyotp
import qrcode
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.primitives.asymmetric import padding as rsa_padding
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.backends import default_backend

# التأكد من وجود مجلد decrypted
if not os.path.exists('decrypted'):
    os.makedirs('decrypted')

# تحميل بيانات fake_data.json للتحقق من اسم المستخدم وكلمة المرور
with open('test_data/fake_data.json', 'r') as f:
    user_data = json.load(f)
stored_username = user_data['login']['username']
stored_password = user_data['login']['password']

# إنشاء مفتاح TOTP وعرض QR للمرة الأولى فقط
if not os.path.exists('user_2fa_secret.txt'):
    totp_secret = pyotp.random_base32()
    with open('user_2fa_secret.txt', 'w') as f:
        f.write(totp_secret)
    uri = pyotp.totp.TOTP(totp_secret).provisioning_uri(name=stored_username, issuer_name="2FA_File_Encryption")
    qr = qrcode.make(uri)
    qr.save('qr_code.png')
    print("✅ QR Code generated and saved as qr_code.png. امسحيه بتطبيق Google Authenticator.")
else:
    with open('user_2fa_secret.txt', 'r') as f:
        totp_secret = f.read()

totp = pyotp.TOTP(totp_secret)

# يطلب من المستخدم إدخال اسم المستخدم وكلمة المرور
input_username = input("Enter username: ")
input_password = input("Enter password: ")

if input_username != stored_username or input_password != stored_password:
    print("❌ Incorrect username or password. Access denied.")
    exit()

# يطلب من المستخدم إدخال OTP
otp_input = input("Enter the 6-digit OTP from Google Authenticator: ")
if not totp.verify(otp_input):
    print("❌ Invalid OTP. Access denied.")
    exit()

print("✅ Username, password, and OTP verified successfully.")

# تحميل المفتاح الخاص مع كلمة المرور
password_input = input("Enter password to decrypt private key: ").encode()
try:
    with open('keys/private_key.pem', 'rb') as f:
        private_key = serialization.load_pem_private_key(
            f.read(),
            password=password_input,
            backend=default_backend()
        )
except ValueError:
    print("❌ Incorrect private key password! Access denied.")
    exit()

# فك تشفير AES Key
with open('encrypted/encrypted_aes_key.bin', 'rb') as f:
    encrypted_aes_key = f.read()

aes_key = private_key.decrypt(
    encrypted_aes_key,
    rsa_padding.OAEP(
        mgf=rsa_padding.MGF1(algorithm=hashes.SHA256()),
        algorithm=hashes.SHA256(),
        label=None
    )
)

# تحميل IV
with open('encrypted/iv.bin', 'rb') as f:
    iv = f.read()

print("✅ AES key and IV decrypted successfully.")

def decrypt_data(encrypted_data, aes_key, iv):
    cipher = Cipher(algorithms.AES(aes_key), modes.CBC(iv), backend=default_backend())
    decryptor = cipher.decryptor()
    padded_data = decryptor.update(encrypted_data) + decryptor.finalize()
    unpadder = padding.PKCS7(128).unpadder()
    data = unpadder.update(padded_data) + unpadder.finalize()
    return data

# فك تشفير الملفات
files = ['fake_data.json', 'fake_message.txt']
for file_name in files:
    with open(f'encrypted/encrypted_{file_name.replace(".", "_")}.bin', 'rb') as f:
        encrypted_file_data = f.read()
    decrypted_file_data = decrypt_data(encrypted_file_data, aes_key, iv)
    with open(f'decrypted/decrypted_{file_name}', 'wb') as f:
        f.write(decrypted_file_data)

print("✅ Files decrypted successfully with 2FA protection!")
