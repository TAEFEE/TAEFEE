import unittest
import sqlite3
import bcrypt
import pyotp
import os

# قاعدة البيانات المؤقتة للتجربة
TEST_DB = 'test_users.db'

def setup_database():
    conn = sqlite3.connect(TEST_DB)
    cursor = conn.cursor()
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        hashed_password TEXT NOT NULL,
        totp_secret TEXT NOT NULL,
        failed_attempts INTEGER DEFAULT 0,
        last_failed TIMESTAMP
    )
    ''')
    conn.commit()
    conn.close()


def register_user(username, password):
    conn = sqlite3.connect(TEST_DB)
    cursor = conn.cursor()
    totp_secret = pyotp.random_base32()
    hashed_pw = bcrypt.hashpw(password.encode(), bcrypt.gensalt())
    try:
        cursor.execute('''
            INSERT INTO users (username, hashed_password, totp_secret)
            VALUES (?, ?, ?)
        ''', (username, hashed_pw, totp_secret))
        conn.commit()
    except sqlite3.IntegrityError:
        conn.close()
        return False
    conn.close()
    return True

def check_password(username, password):
    conn = sqlite3.connect(TEST_DB)
    cursor = conn.cursor()
    cursor.execute("SELECT hashed_password FROM users WHERE username = ?", (username,))
    result = cursor.fetchone()
    conn.close()
    if result:
        return bcrypt.checkpw(password.encode(), result[0])
    return False

def get_totp_secret(username):
    conn = sqlite3.connect(TEST_DB)
    cursor = conn.cursor()
    cursor.execute("SELECT totp_secret FROM users WHERE username = ?", (username,))
    result = cursor.fetchone()
    conn.close()
    return result[0] if result else None

class TestAuth(unittest.TestCase):
    def setUp(self):
        if os.path.exists(TEST_DB):
            os.remove(TEST_DB)
        setup_database()

    def test_register_user_success(self):
        self.assertTrue(register_user("taef", "Password123"))

    def test_register_user_duplicate(self):
        register_user("taef", "Password123")
        self.assertFalse(register_user("taef", "Password123"))

    def test_password_check_correct(self):
        register_user("mohammed", "Secret123")
        self.assertTrue(check_password("mohammed", "Secret123"))

    def test_password_check_incorrect(self):
        register_user("mohammed", "Secret123")
        self.assertFalse(check_password("mohammed", "WrongPass"))

    def test_totp_verification(self):
        register_user("ahmed", "OtpPass123")
        secret = get_totp_secret("ahmed")
        totp = pyotp.TOTP(secret)
        current_otp = totp.now()
        self.assertTrue(totp.verify(current_otp))

if __name__ == '__main__':
    unittest.main()