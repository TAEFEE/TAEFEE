import os
import shutil
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives import serialization

# دالة تدوير المفاتيح
def rotate_keys():
    if not os.path.exists('keys/old'):
        os.makedirs('keys/old')
    if os.path.exists('keys/private_key.pem'):
        shutil.move('keys/private_key.pem', 'keys/old/private_key_old.pem')
    if os.path.exists('keys/public_key.pem'):
        shutil.move('keys/public_key.pem', 'keys/old/public_key_old.pem')
    print("✅ Key rotation done, old keys moved to keys/old/.")

# التأكد من وجود مجلد keys
if not os.path.exists('keys'):
    os.makedirs('keys')

rotate_keys()

# توليد كلمة المرور
password_input = input("Enter password to protect the private key: ").encode()

# توليد المفاتيح
private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
public_key = private_key.public_key()

# حفظ المفتاح الخاص
with open('keys/private_key.pem', 'wb') as f:
    f.write(private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.BestAvailableEncryption(password_input)
    ))

# حفظ المفتاح العام
with open('keys/public_key.pem', 'wb') as f:
    f.write(public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo
    ))

print("✅ Keys generated and saved successfully!")
