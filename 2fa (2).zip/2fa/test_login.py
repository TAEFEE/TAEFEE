import json

# قراءة بيانات fake_data.json
with open('test_data/fake_data.json', 'r') as f:
    data = json.load(f)

stored_username = data['login']['username'].strip()
stored_password = data['login']['password'].strip()

# إدخال من المستخدم
input_username = input("Enter username: ").strip()
input_password = input("Enter password: ").strip()

print(f"📌 Expected username: {stored_username}")
print(f"📌 You entered: {input_username}")

print(f"📌 Expected password: {stored_password}")
print(f"📌 You entered: {input_password}")

if input_username != stored_username or input_password != stored_password:
    print("❌ Incorrect username or password. Access denied.")
    exit()

print("✅ Username and password correct!")

