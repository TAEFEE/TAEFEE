import sqlite3
import bcrypt
import pyotp
import qrcode

# إنشاء قاعدة البيانات وجدول المستخدمين إذا ما كان موجود
conn = sqlite3.connect('users.db')
cursor = conn.cursor()

cursor.execute('''
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    hashed_password TEXT NOT NULL,
    totp_secret TEXT NOT NULL,
    failed_attempts INTEGER DEFAULT 0,
    last_failed TIMESTAMP
)
''')
conn.commit()

# تسجيل مستخدم جديد
def register_user(username, password):
    # توليد سر المصادقة الثنائية
    totp_secret = pyotp.random_base32()
    
    # تشفير كلمة المرور
    hashed_pw = bcrypt.hashpw(password.encode(), bcrypt.gensalt())

    try:
        cursor.execute('''
            INSERT INTO users (username, hashed_password, totp_secret)
            VALUES (?, ?, ?)
        ''', (username, hashed_pw, totp_secret))
        conn.commit()
        print(f"✅ تم تسجيل المستخدم: {username}")
        
        # توليد رابط TOTP
        totp = pyotp.TOTP(totp_secret)
        uri = totp.provisioning_uri(name=username, issuer_name="SecureApp")
        
        # إنشاء QR code وحفظه كصورة
        qr = qrcode.make(uri)
        qr.save("user_qr_code.png")
        print("📷 تم حفظ كود QR في ملف user_qr_code.png، امسحيه باستخدام Google Authenticator")

    except sqlite3.IntegrityError:
        print("❌ اسم المستخدم موجود مسبقًا")

# مثال: تسجيل مستخدم
register_user("taef", "StrongPassword123")
