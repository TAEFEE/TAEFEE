import os
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.primitives.asymmetric import padding as rsa_padding
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.backends import default_backend

# التأكد من وجود مجلد decrypted
if not os.path.exists('decrypted'):
    os.makedirs('decrypted')

# تحميل المفتاح الخاص بكلمة مرور من المستخدم
password_input = input("Enter password to decrypt private key: ").encode()

try:
    with open('keys/private_key.pem', 'rb') as f:
        private_key = serialization.load_pem_private_key(
            f.read(),
            password=password_input,
            backend=default_backend()
        )
except ValueError:
    print("❌ Incorrect password! Access denied.")
    exit()

with open('encrypted/encrypted_aes_key.bin', 'rb') as f:
    encrypted_aes_key = f.read()

aes_key = private_key.decrypt(
    encrypted_aes_key,
    rsa_padding.OAEP(
        mgf=rsa_padding.MGF1(algorithm=hashes.SHA256()),
        algorithm=hashes.SHA256(),
        label=None
    )
)

with open('encrypted/iv.bin', 'rb') as f:
    iv = f.read()

print("✅ AES key and IV decrypted successfully!")

def decrypt_data(encrypted_data, aes_key, iv):
    cipher = Cipher(algorithms.AES(aes_key), modes.CBC(iv), backend=default_backend())
    decryptor = cipher.decryptor()

    padded_data = decryptor.update(encrypted_data) + decryptor.finalize()

    unpadder = padding.PKCS7(128).unpadder()
    data = unpadder.update(padded_data) + unpadder.finalize()

    return data

files = ['fake_data.json', 'fake_message.txt']

for file_name in files:
    with open(f'encrypted/encrypted_{file_name.replace(".", "_")}.bin', 'rb') as f:
        encrypted_file_data = f.read()

    decrypted_file_data = decrypt_data(encrypted_file_data, aes_key, iv)

    with open(f'decrypted/decrypted_{file_name}', 'wb') as f:
        f.write(decrypted_file_data)

print("✅ Files decrypted successfully!")
