def register_user(username, password):
    totp_secret = pyotp.random_base32()
    hashed_pw = bcrypt.hashpw(password.encode(), bcrypt.gensalt())

    try:
        cursor.execute('''
            INSERT INTO users (username, hashed_password, totp_secret)
            VALUES (?, ?, ?)
        ''', (username, hashed_pw, totp_secret))
        conn.commit()
        print(f"✅ تم تسجيل المستخدم: {username}")

        totp = pyotp.TOTP(totp_secret)
        uri = totp.provisioning_uri(name=username, issuer_name="SecureApp")
        qr = qrcode.make(uri)
        qr.save(f"{username}_qr.png")
        print(f" تم حفظ كود QR في ملف {username}_qr.png")

    except sqlite3.IntegrityError:
        print("❌ اسم المستخدم موجود مسبقًا")
