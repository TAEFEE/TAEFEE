import sqlite3
import bcrypt
import pyotp
import time
from datetime import datetime, timedelta

MAX_ATTEMPTS = 3
BLOCK_DURATION = 60  # بالثواني (1 دقيقة)

def login():
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()

    username = input("👤 أدخل اسم المستخدم: ")
    password = input("🔑 أدخل كلمة المرور: ")

    cursor.execute("SELECT hashed_password, totp_secret, failed_attempts, last_failed FROM users WHERE username = ?", (username,))
    result = cursor.fetchone()

    if result:
        hashed_pw, totp_secret, attempts, last_failed = result

        # 🛡️ التحقق من الحظر المؤقت
        if attempts >= MAX_ATTEMPTS:
            if last_failed:
                last_failed_time = datetime.strptime(last_failed, "%Y-%m-%d %H:%M:%S.%f")
                if datetime.now() - last_failed_time < timedelta(seconds=BLOCK_DURATION):
                    remaining = BLOCK_DURATION - (datetime.now() - last_failed_time).seconds
                    print(f"⏳ تم حظر الحساب مؤقتًا. حاول مرة أخرى بعد {remaining} ثانية.")
                    conn.close()
                    return
                else:
                    # reset attempts after block duration
                    cursor.execute("UPDATE users SET failed_attempts = 0 WHERE username = ?", (username,))
                    conn.commit()
                    attempts = 0

        # ✅ التحقق من كلمة المرور
        if bcrypt.checkpw(password.encode(), hashed_pw):
            otp = input("🔐 أدخل رمز التحقق (OTP): ")
            totp = pyotp.TOTP(totp_secret)

            if totp.verify(otp):
                print("✅ تم تسجيل الدخول بنجاح 🎉")
                # إعادة تعيين المحاولات الفاشلة
                cursor.execute("UPDATE users SET failed_attempts = 0, last_failed = NULL WHERE username = ?", (username,))
                conn.commit()
            else:
                print("❌ رمز التحقق غير صحيح.")
                cursor.execute("UPDATE users SET failed_attempts = failed_attempts + 1, last_failed = ? WHERE username = ?", (str(datetime.now()), username))
                conn.commit()
        else:
            print("❌ كلمة المرور غير صحيحة.")
            cursor.execute("UPDATE users SET failed_attempts = failed_attempts + 1, last_failed = ? WHERE username = ?", (str(datetime.now()), username))
            conn.commit()
    else:
        print("❌ اسم المستخدم غير موجود.")

    conn.close()

# تشغيل تسجيل الدخول
login()
