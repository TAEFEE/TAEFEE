import os
import secrets
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.primitives.asymmetric import padding as rsa_padding
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.backends import default_backend

# توليد مفتاح AES و IV
aes_key = secrets.token_bytes(32)
iv = secrets.token_bytes(16)

if not os.path.exists('encrypted'):
    os.makedirs('encrypted')

# تحميل المفتاح العام
with open('keys/public_key.pem', 'rb') as f:
    public_key = serialization.load_pem_public_key(f.read())

# تشفير مفتاح AES
encrypted_aes_key = public_key.encrypt(
    aes_key,
    rsa_padding.OAEP(
        mgf=rsa_padding.MGF1(algorithm=hashes.SHA256()),
        algorithm=hashes.SHA256(),
        label=None
    )
)

with open('encrypted/encrypted_aes_key.bin', 'wb') as f:
    f.write(encrypted_aes_key)

with open('encrypted/iv.bin', 'wb') as f:
    f.write(iv)

print("✅ AES key and IV encrypted and saved!")

def encrypt_data(data, aes_key, iv):
    padder = padding.PKCS7(128).padder()
    padded_data = padder.update(data) + padder.finalize()

    cipher = Cipher(algorithms.AES(aes_key), modes.CBC(iv), backend=default_backend())
    encryptor = cipher.encryptor()
    encrypted_data = encryptor.update(padded_data) + encryptor.finalize()
    return encrypted_data

# تشفير الملفات
files = ['fake_data.json', 'fake_message.txt']

for file_name in files:
    with open(f'test_data/{file_name}', 'rb') as f:
        file_data = f.read()

    encrypted_file_data = encrypt_data(file_data, aes_key, iv)

    with open(f'encrypted/encrypted_{file_name.replace(".", "_")}.bin', 'wb') as f:
        f.write(encrypted_file_data)

print("✅ Files encrypted successfully!")

