import sqlite3
import bcrypt
import pyotp
import qrcode

# فتح أو إنشاء قاعدة البيانات
conn = sqlite3.connect('users.db')
cursor = conn.cursor()

# إنشاء جدول المستخدمين (إذا ما كان موجود)
cursor.execute('''
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    hashed_password TEXT NOT NULL,
    totp_secret TEXT NOT NULL,
    failed_attempts INTEGER DEFAULT 0,
    last_failed TIMESTAMP
)
''')
conn.commit()

# دالة تسجيل مستخدم
def register_user(username, password):
    totp_secret = pyotp.random_base32()
    hashed_pw = bcrypt.hashpw(password.encode(), bcrypt.gensalt())

    try:
        cursor.execute('''
            INSERT INTO users (username, hashed_password, totp_secret)
            VALUES (?, ?, ?)
        ''', (username, hashed_pw, totp_secret))
        conn.commit()
        print(f" تم تسجيل المستخدم: {username}")

        # توليد QR Code
        totp = pyotp.TOTP(totp_secret)
        uri = totp.provisioning_uri(name=username, issuer_name="SecureApp")
        qr = qrcode.make(uri)
        qr.save(f"{username}_qr.png")
        print(f" QR محفوظ في ملف: {username}_qr.png")

    except sqlite3.IntegrityError:
        print(" اسم المستخدم موجود مسبقًا")

#  تسجيل أمثلة
register_user("taef", "StrongPassword123")
register_user("sara", "MySecurePass456")

#  تغلق الاتصال بعد الانتهاء
conn.close()
